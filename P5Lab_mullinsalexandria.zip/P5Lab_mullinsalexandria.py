#alexandria mullins
#12/13/2025
#P5 Lab
#This program calculates change for a self-checkout system.


import random

def disperse_change(change):
    """
    Takes a float amount of change and prints the amount of dollars, quarters,
    dimes, nickels, and pennies required to make that change.
    """
    # Convert change to cents to avoid floating point issues
    cents = round(change * 100)
    
    dollars = cents // 100
    cents %= 100
    
    quarters = cents // 25
    cents %= 25
    
    dimes = cents // 10
    cents %= 10
    
    nickels = cents // 5
    cents %= 5
    
    pennies = cents
    
    print(f"\nChange is: ${change:.2f}\n")
    print(f"{dollars} Dollars")
    print(f"{quarters} Quarters")
    print(f"{dimes} Dimes")
    print(f"{nickels} Nickels")
    print(f"{pennies} Pennies")

def main():
    # Generate random amount owed between $0.01 and $100.00
    amount_owed = round(random.uniform(0.01, 100.00), 2)
    
    print(f"You owe ${amount_owed:.2f}")
    
    # Prompt user to enter cash amount
    while True:
        try:
            cash_given = float(input("How much cash will you put in the self-checkout? "))
            if cash_given < amount_owed:
                print("You did not provide enough cash. Please enter an amount equal or greater than the amount owed.")
            else:
                break
        except ValueError:
            print("Invalid input. Please enter a valid number.")
    
    change = round(cash_given - amount_owed, 2)
    
    # Call the function to disperse change
    disperse_change(change)

# Call main function to run the program
if __name__ == "__main__":
    main()


