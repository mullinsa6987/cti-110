#Alexandria Mullins
# Final Project 
#12/13/2025

import random
import time

# Main character dictionary
player = {
    "name": "",
    "health": 100,
    "magic": 10,
    "inventory": {"Pixie Dust": 1}
}

# Function to display player status
def show_status():
    print(f"\n💖 Health: {player['health']}")
    print(f"✨ Magic: {player['magic']}")
    print(f"🎒 Inventory: {player['inventory']}\n")

# Function for exploring
def explore():
    print("You wander through the magical kingdom...")
    time.sleep(1)
    
    encounter = random.choice(["treasure", "villain", "friend", "nothing"])
    
    if encounter == "treasure":
        magic_found = random.randint(5, 20)
        player["magic"] += magic_found
        print(f"🏰 You found a magical artifact! Magic increased by {magic_found}!")
    
    elif encounter == "villain":
        damage = random.randint(5, 30)
        player["health"] -= damage
        print(f"👹 A villain attacked you! You lost {damage} health!")
    
    elif encounter == "friend":
        potion_found = random.choice([True, False])
        if potion_found:
            player["inventory"]["Pixie Dust"] = player["inventory"].get("Pixie Dust", 0) + 1
            print("🧚‍♀️ A friendly fairy gives you some Pixie Dust!")
        else:
            print("🤝 A friend cheers you on and you feel brave!")
    
    else:
        print("🌸 You stroll through the enchanted garden peacefully.")

# Function to use Pixie Dust
def use_pixie_dust():
    if player["inventory"].get("Pixie Dust", 0) > 0:
        player["inventory"]["Pixie Dust"] -= 1
        heal = random.randint(10, 30)
        player["health"] += heal
        print(f"🧚 You sprinkled Pixie Dust and restored {heal} health!")
    else:
        print("❌ You have no Pixie Dust left!")

# Main game function
def main():
    print("🌟 Welcome to Disney's Magical Adventure! 🌟")
    player["name"] = input("Enter your Disney hero's name: ")
    print(f"\nHello {player['name']}! Your magical adventure begins now...")
    
    while player["health"] > 0:
        show_status()
        print("Choose an action:")
        print("1. Explore the Kingdom 🌸")
        print("2. Use Pixie Dust 🧚")
        print("3. Quit ❌")
        
        choice = input("Enter the number of your choice: ")
        
        if choice == "1":
            explore()
        elif choice == "2":
            use_pixie_dust()
        elif choice == "3":
            print("Thanks for playing! Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")
        
        # Random chance to find Pixie Dust while exploring
        if random.random() < 0.2:
            player["inventory"]["Pixie Dust"] = player["inventory"].get("Pixie Dust", 0) + 1
            print("🎁 You discovered some Pixie Dust during your journey!")
        
        time.sleep(1)
    
    if player["health"] <= 0:
        print(f"💀 Oh no, {player['name']} has been defeated! Game Over.")

# Run the game
if __name__ == "__main__":
    main()