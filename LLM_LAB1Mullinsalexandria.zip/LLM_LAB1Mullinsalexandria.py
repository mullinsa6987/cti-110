#Alexandria Mullins
#12/7/2025
# Stranger Things Quiz Game

def play_quiz():
    score = 0

    questions = [
        {
            "question": "1. What is the name of the alternate dimension in Stranger Things?",
            "choices": ["A) The Underworld", "B) The Upside Down", "C) The Backwards Realm"],
            "answer": "B"
        },
        {
            "question": "2. What is Eleven's favorite food?",
            "choices": ["A) Waffles", "B) Pizza", "C) Ice Cream"],
            "answer": "A"
        },
        {
            "question": "3. What is the name of the town where Stranger Things takes place?",
            "choices": ["A) Hawkins", "B) Woodpine", "C) Riverton"],
            "answer": "A"
        },
        {
            "question": "4. What is the name of the creature from Season 1?",
            "choices": ["A) Mind Flayer", "B) Demogorgon", "C) Demodog"],
            "answer": "B"
        },
        {
            "question": "5. What is Eleven’s real name?",
            "choices": ["A) Eliza Byers", "B) Jane Hopper", "C) Jane Ives"],
            "answer": "C"
        }
    ]

    print("\nWelcome to the Stranger Things Quiz!\n")

    for q in questions:
        print(q["question"])
        for choice in q["choices"]:
            print(choice)
        
        # Validate input
        while True:
            user_answer = input("Your answer (A, B, or C): ").strip().upper()
            if user_answer in ["A", "B", "C"]:
                break
            else:
                print("Invalid input. Please enter A, B, or C.")

        if user_answer == q["answer"]:
            print("Correct!\n")
            score += 1
        else:
            print(f"Incorrect! The correct answer was {q['answer']}.\n")

    print(f"You scored {score} out of {len(questions)}!")
    print(f"Your percentage: {score / len(questions) * 100:.1f}%\n")


# Main loop for replay
while True:
    play_quiz()
    replay = input("Do you want to play again? (yes/no): ").strip().lower()
    if replay not in ["yes", "y"]:
        print("Thanks for playing! See you in the Upside Down!")
        break
