#Alexandria Mullins
#P4 Lab 1
#12/1/2025
# Use turtle and loops to draw a square and a triangle

#import the library
import turtle

# Create the turtle window and drawing object
win = turtle.Screen
pen = turtle.Turtle()

# Set turtle options
pen.pensize(5)
pen.pencolor("pink")
pen.shape("arrow")

#code to draw the shapes
for side in range(4):
    pen.forward(100)
    pen.left(90)
#while loop that executes 3 times
sides= 3

while sides > 0:
 print(sides)
 pen.forward(100)
 pen.left(120)  
 
 sides= sides - 1 


#wait for user to close window
win.mainloop()