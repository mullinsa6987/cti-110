#Alexandria Mullins
#P4 Lab 2
#12/1/2025
#use while loop and for loop together

'''
Get integer from user
determine if the integer is positive or negative 
if number is positive, display multiplication table
if number is negative tell user program cannot accept it
ask user to run again?
if yes, run program
if no, end program
'''

run_again = 'yes'
while run_again != "no":
  
    user_num = int(input("Enter an integer: "))
    if user_num >= 0:
        #display multiplication- for that value and range (1-13)
        for item in range (1, 14) :
            print(f"{user_num} * {item} = {user_num * item}") 
    else: 
        print("this program does not handle negative values")
    run_again = input("would you like to run the program again? ")

#Loop has broken. User entered 'no'  
print("program is ending...")
