#Alexandria Mullins
#Date: 12/03/2025
#P4HW1
# edit and enhance exiting programs




"""
PSEUDOCODE

1. Ask user how many scores they want to enter.
2. Create an empty list to hold the scores.
3. Loop from 1 to the number of scores:
    a. Ask user to enter score #i.
    b. If the score is not between 0 and 100:
    - Display: "INVALID Score entered!!!"
    - Display: "Score should be between 0 and 100"
    - Ask user to enter the same score # again until valid.
    c. Add the valid score to the list.
4. After all scores are entered:
    - Find the lowest score.
    - Create a modified list with the lowest score removed.
    - Compute the average of the modified list.
5. Determine the letter grade from the average.
6. Display results in the exact format shown.
"""
# Ask for number of scores
num_scores = int(input("How many scores do you want to enter? "))

# List to store scores
scores = []

# Collect scores
for i in range(1, num_scores + 1):
    score = float(input(f"\nEnter score #{i}: "))

# Validate score
    while score < 0 or score > 100:
        print("\nINVALID Score entered!!!!")
        print("Score should be between 0 and 100")
        score = float(input(f"Enter score #{i} again: "))

    scores.append(score)

# Processing
lowest = min(scores)
modified_scores = scores.copy()
modified_scores.remove(lowest)
average = sum(modified_scores) / len(modified_scores)

# Letter grade
if average >= 90:
    grade = "A"
elif average >= 80:
    grade = "B"
elif average >= 70:
    grade = "C"
elif average >= 60:
    grade = "D"
else:
    grade = "F"

# Output
print("\n--------------Results------------")

print(f"Lowest Score  : {lowest}")
print(f"Modified List : {modified_scores}")
print(f"Scores Average: {average:.2f}")
print(f"Grade         : {grade}")

print("---------------------------------")