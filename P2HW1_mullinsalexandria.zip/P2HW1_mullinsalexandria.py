#Alexandria Mullins
#11/15/2025
#P2HW1_mullinsalexandria.py
#Assess student ability to edit and enhance exiting programs

# Get input from user
# Get user input
budget = float(input("Enter your budget: "))
destination = input("Enter your travel destination: ")
gas = float(input("How much will you spend on gas? "))
accommodation = float(input("How much will you spend on accommodation? "))
food = float(input("How much will you spend on food? "))

# Calculate totals
total_expenses = gas + accommodation + food
remaining = budget - total_expenses

# Output
print("\nTravel Summary for", destination)
print("{:<20} {:>12}".format("Category", "Amount"))

print("{:<20} ${:>11.2f}".format("Budget", budget))
print("{:<20} ${:>11.2f}".format("Gas", gas))
print("{:<20} ${:>11.2f}".format("Accommodation", accommodation))
print("{:<20} ${:>11.2f}".format("Food", food))
print("{:<20} ${:>11.2f}".format("Total Expenses", total_expenses))
print("{:<20} ${:>11.2f}".format("Remaining Budget", remaining))