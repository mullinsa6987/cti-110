
# Alexandria Mullins
# 12/07/2025
# P4HW2 – Multi-Employee Salary Calculator
# This program calculates regular pay, overtime pay, and gross pay for multiple employees.

"""
Pseudocode:

1. Initialize total_regular_pay, total_overtime_pay, total_gross_pay, and employee_count to 0.
2. Loop indefinitely:
    a. Ask user for employee name.
    b. If employee name is 'Done' (case-insensitive), exit the loop.
    c. Ask user for hours worked and pay rate. Ensure they are numeric.
    d. Calculate regular hours, overtime hours, regular pay, overtime pay, and gross pay.
    e. Display the employee's pay information.
    f. Add each employee's pay to running totals.
    g. Increment employee_count.
3. After the loop ends, display totals for all employees.
"""

# Initialize totals
total_regular_pay = 0
total_overtime_pay = 0
total_gross_pay = 0
employee_count = 0

while True:
    # Get employee name
    name = input("Enter employee name (or 'Done' to finish): ").strip()
    
    if name.lower() == "done":
        break  # Exit loop if sentinel is entered

    # Get hours worked and pay rate
    try:
        hours = float(input(f"Enter hours worked for {name}: "))
        pay_rate = float(input(f"Enter hourly pay rate for {name}: "))
    except ValueError:
        print("Invalid input! Please enter numeric values for hours and pay rate.")
        continue  # Ask for this employee again

    # Calculate pay
    if hours > 40:
        overtime_hours = hours - 40
        overtime_pay = overtime_hours * pay_rate * 1.5
        regular_pay = 40 * pay_rate
    else:
        overtime_hours = 0
        overtime_pay = 0
        regular_pay = hours * pay_rate

    gross_pay = regular_pay + overtime_pay

    # Display individual employee info
    print("\n-----------------------------")
    print(f"Employee Name: {name}")
    print(f"{'Hours Worked':<15}{'Pay Rate':<12}{'Overtime Pay':<15}{'Regular Pay':<15}{'Gross Pay':<12}")
    print("-----------------------------")
    print(f"{hours:<15}{pay_rate:<12.2f}{overtime_pay:<15.2f}{regular_pay:<15.2f}{gross_pay:<12.2f}\n")

    # Update totals
    total_regular_pay += regular_pay
    total_overtime_pay += overtime_pay
    total_gross_pay += gross_pay
    employee_count += 1

# Display totals
print("\n===== Payroll Summary =====")
print(f"Total Regular Pay: ${total_regular_pay:.2f}")
print(f"Total Overtime Pay: ${total_overtime_pay:.2f}")
print(f"Total Gross Pay: ${total_gross_pay:.2f}")
print(f"Number of Employees Entered: {employee_count}")