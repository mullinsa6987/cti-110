#Alexandria Mullins
#10/23/2025
#salary calculator

# request employee info
name = input("Enter employee name: ")
hours = float(input("Enter hours worked: "))
rate = float(input("Enter hourly pay rate: "))

# Evaluate overtime 
if hours > 40:
    #calculate overtime

    overtime_hours = hours - 40
    #calculate over pay
    overtime_pay = overtime_hours * (rate * 1.5)
    #calculate salary for regular hours
    regular_pay = 40 * rate
    # calculate gross pay
    gross_pay = regular_pay + overtime_pay
else:
    overtime_pay = 0
    overtime_hours = 0
    regular_pay = hours * rate
    gross_pay = regular_pay

# Display results
print("-----------------------------")
print(f"Employee Name:", name)
print(f'{"Hours worked":<15}{"pay rate":<12}{"overtime pay":<12}{"regular pay":<15}{"gross pay":<12}')
print(("----------------------------"))
print(f'{hours:<15}{rate:<12}{overtime_pay:<12}{regular_pay:<15}{gross_pay:<12}')