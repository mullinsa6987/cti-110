#Alexandria Mullins
# 11/14/2025
# P1HW2_mullinsalexandria.py
# This program ask user for their trip budget and expenses,
#calculates the total expenses and remaining budget after expenses.

budget = int (input("Enter your budget: "))
destination = input("Enter your travel destination: ")
gas = int (input("How much will you spend on gas? "))
accommodation = int (input("How much will you spend on accommodation? "))
food = int (input("How much will you spend on food? "))

# Calculate total expenses and remaining balance
total_expenses = gas + accommodation + food
remaining = budget - total_expenses

print("Travel Summary for", destination)
print("Total Budget:", budget)
print("Total Expenses:", total_expenses)
print("Remaining Budget:", remaining)

# ---------------------- PSEUDOCODE ----------------------

# 1.Ask user to enter their total trip budget
# 2. Ask user to enter their travel destination
# 3. Ask user to enter the amount they will spend on gas
# 4. Ask user to enter the amount they will spend on accommodation
# 5. Ask user to enter the amount they will spend on food
# 6. Add all expenses (gas + accommodation + food)
# 7. Subtract total expenses from the budget to calculate remaining balance
# 8. Display destination
# 9. Display total expenses
# 10. Display remaining balance
# ---------------------------------------------------------