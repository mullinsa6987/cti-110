#alexandria mullins
#P3HW1_mullinsalexandria.py
#This program calculates the lowest, highest, sum, and average of six module grades
#11/28/2025

print("Enter grades for six modules:")

mod_1 = float(input("Enter grade for Module 1: "))
mod_2 = float(input("Enter grade for Module 2: "))
mod_3 = float(input("Enter grade for Module 3: "))
mod_4 = float(input("Enter grade for Module 4: "))
mod_5 = float(input("Enter grade for Module 5: "))
mod_6 = float(input("Enter grade for Module 6: "))

# ----- Process Section -----
# Add grades to a list
grades = [mod_1, mod_2, mod_3, mod_4, mod_5, mod_6]

# Calculate lowest, highest, sum, and average
low = min(grades)
high = max(grades)
total = sum(grades)
avg = total / len(grades)

# ----- Output Section -----
print("---------- Grade Summary ----------")
print(f"Lowest Grade:   {low}")
print(f"Highest Grade:  {high}")
print(f"Sum of Grades:  {total}")
print(f"Average Grade:  {avg:.2f}")
print("-----------------------------------")

# ----- Determine Letter Grade -----
print("-------- Letter Grade --------")

if avg >= 90:
    print("Your grade is: A")
elif avg >= 80:
    print("Your grade is: B")
elif avg >= 70:
    print("Your grade is: C")
elif avg >= 60:
    print("Your grade is: D")
else:
    print("Your grade is: F")
